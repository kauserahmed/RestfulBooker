package com.restful_booker.testCase;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class CreateBooking {
	
	@Test
	void CreatingBooking() {
		// Specify base URI
		
		RestAssured.baseURI = "https://restful-booker.herokuapp.com/booking";
		
		//creating request object 
		RequestSpecification httpRequest=RestAssured.given();
		
		
		//Response object along with the parameter. 
		// sending data to the server
		
		//creating body 
		JSONObject requestParamerter = new JSONObject();
		requestParamerter.put("firstname", "Jim");
		requestParamerter.put("lastname", "Brown");
		requestParamerter.put("totalprice", 111);
		requestParamerter.put("depositpaid", true);
		requestParamerter.put("additionalneeds", "Breakfast");
		
		httpRequest.header("Content-Type", "application/json"); 
		httpRequest.body(requestParamerter.toJSONString()); //attached above data to the request
		
		
		//Response object 
		Response response = httpRequest.request(Method.POST);
		
		
		//print response in console window 
		String responseBody = response.getBody().asString();
		System.out.println("Response Body is: " + responseBody);
		
		//Status code validation
		int statusCode = response.getStatusCode();
		System.out.println("Status code is: " + statusCode);
		Assert.assertEquals(statusCode, 200); //Wrong status code
		//Status line verification 
		String statusLine = response.getStatusLine();
		System.out.println("Status line is: " + statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK"); //wrong status line
		
		
	}

}